export interface BodyShape {
  id: string;
  name: string;
  description: string;
  image: string;
  characteristics: string[];
}

export interface BikiniRecommendation {
  tops: string[];
  bottoms: string[];
  onePieces: string[];
  colors: string[];
  patterns: string[];
  avoid: string[];
  tips: string[];
}

export interface BodyShapeDetails extends BodyShape {
  recommendations: BikiniRecommendation;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: {
    id: string;
    text: string;
    shapeScores: Record<string, number>;
  }[];
}

export interface QuizResult {
  shape: BodyShapeDetails;
  confidence: number;
}

export interface SizeGuide {
  region: string;
  sizes: {
    size: string;
    bust: string;
    waist: string;
    hips: string;
  }[];
}

export interface ConfidenceTip {
  id: string;
  title: string;
  description: string;
  icon: string;
}
