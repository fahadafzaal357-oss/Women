import type { BodyShapeDetails, QuizQuestion, SizeGuide, ConfidenceTip } from '@/types';

export const bodyShapes: BodyShapeDetails[] = [
  {
    id: 'hourglass',
    name: 'Hourglass',
    description: 'Balanced bust and hips with a beautifully defined waist',
    image: '/shape-hourglass.jpg',
    characteristics: [
      'Shoulders and hips are similar in width',
      'Clearly defined, narrow waist',
      'Bust and hips are proportionate',
      'Curvy silhouette'
    ],
    recommendations: {
      tops: [
        'Triangle tops with mid-way straps',
        'Strapless bandeau tops',
        'Underwire bikini tops',
        'Halter neck styles'
      ],
      bottoms: [
        'High-waisted bikini bottoms',
        'Simple string bikini bottoms',
        'High-leg cut styles',
        'Full coverage bottoms'
      ],
      onePieces: [
        'Belted swimsuits',
        'Wrap-style one-pieces',
        'Cut-out monokinis',
        'Plunging V-neck swimsuits'
      ],
      colors: [
        'Matching sets in bold colors',
        'Classic black',
        'Vibrant coral or red',
        'Navy blue'
      ],
      patterns: [
        'Solid colors for elegance',
        'Subtle prints',
        'Color blocking',
        'Small florals'
      ],
      avoid: [
        'Mismatched tops and bottoms',
        'Overly busy patterns',
        'Loose, shapeless styles'
      ],
      tips: [
        'Emphasize your defined waist with high-waisted bottoms',
        'Choose matching sets to maintain balance',
        'Show off your curves with structured styles',
        'Underwire tops provide excellent support'
      ]
    }
  },
  {
    id: 'pear',
    name: 'Pear',
    description: 'Wider hips with a smaller bust and defined waist',
    image: '/shape-pear.jpg',
    characteristics: [
      'Hips are wider than shoulders',
      'Defined waistline',
      'Smaller bust',
      'Fuller thighs and hips'
    ],
    recommendations: {
      tops: [
        'Push-up bikini tops',
        'Tops with ruffles or embellishments',
        'Bold patterns and prints on top',
        'Off-shoulder styles',
        'Halter necks with wide straps'
      ],
      bottoms: [
        'Dark-colored bikini bottoms',
        'High-cut leg styles',
        'Simple, minimal bottoms',
        'Avoid high-waisted unless ruched'
      ],
      onePieces: [
        'Plunging necklines',
        'One-pieces with eye-catching tops',
        'Styles with ruching at the waist',
        'Diagonal color blocking'
      ],
      colors: [
        'Light or bright colors on top',
        'Dark colors on bottom',
        'Color blocking to balance',
        'Avoid matching light colors'
      ],
      patterns: [
        'Bold prints on top',
        'Stripes or florals upstairs',
        'Solid dark bottoms',
        'Mix and match patterns'
      ],
      avoid: [
        'High-waisted bottoms that emphasize hips',
        'Busy patterns on bottom',
        'Boy shorts or full coverage bottoms',
        'Horizontal stripes on lower half'
      ],
      tips: [
        'Draw attention upward with embellished tops',
        'Keep bottoms simple and dark',
        'High-cut legs elongate your silhouette',
        'Balance your proportions with visual interest on top'
      ]
    }
  },
  {
    id: 'apple',
    name: 'Apple',
    description: 'Fuller midsection with slimmer legs and often fuller bust',
    image: '/shape-apple.jpg',
    characteristics: [
      'Rounder midsection',
      'Fuller bust',
      'Slimmer legs and arms',
      'Less defined waist'
    ],
    recommendations: {
      tops: [
        'Fuller coverage bikini tops',
        'Underwire for support',
        'V-neck or plunge styles',
        'Tankini tops',
        'Ruched or gathered fabrics'
      ],
      bottoms: [
        'High-waisted bikini bottoms',
        'Tummy control styles',
        'Skirted bottoms',
        'Dark colors for smoothing'
      ],
      onePieces: [
        'Tummy control swimsuits',
        'Ruched one-pieces',
        'Wrap-style swimsuits',
        'Deep V-necklines',
        'Side panel designs'
      ],
      colors: [
        'Dark colors for slimming effect',
        'Ruching in solid colors',
        'Strategic color blocking',
        'Avoid light colors on midsection'
      ],
      patterns: [
        'Small, subtle prints',
        'Diagonal patterns',
        'Vertical details',
        'Dark base colors'
      ],
      avoid: [
        'Horizontal stripes on midsection',
        'Low-rise bottoms',
        'Too-tight styles',
        'Bright colors on tummy area'
      ],
      tips: [
        'Look for tummy control panels',
        'Draw attention to your great legs with high cuts',
        'V-necks elongate your torso',
        'Ruching camouflages beautifully'
      ]
    }
  },
  {
    id: 'inverted-triangle',
    name: 'Inverted Triangle',
    description: 'Broader shoulders with narrower hips and often fuller bust',
    image: '/shape-inverted-triangle.jpg',
    characteristics: [
      'Shoulders wider than hips',
      'Fuller bust',
      'Narrower hips',
      'Athletic build'
    ],
    recommendations: {
      tops: [
        'Simple, solid color tops',
        'Halter necks with thick straps',
        'Minimizer styles if needed',
        'Avoid strapless if large busted'
      ],
      bottoms: [
        'Embellished bikini bottoms',
        'Side-tie bottoms',
        'Ruffled or frilled bottoms',
        'Brazilian or cheeky cuts',
        'Bright colors and prints'
      ],
      onePieces: [
        'High-leg cut swimsuits',
        'Hip embellishment details',
        'Cut-out sides',
        'Deep necklines'
      ],
      colors: [
        'Darker colors on top',
        'Bright, bold colors on bottom',
        'Color blocking with dark up top',
        'Prints on lower half'
      ],
      patterns: [
        'Solid dark tops',
        'Busy prints on bottoms',
        'Horizontal stripes on hips',
        'Floral or tropical prints below'
      ],
      avoid: [
        'Strapless tops',
        'Thin spaghetti straps',
        'Dark colors on bottom',
        'Minimal coverage on hips'
      ],
      tips: [
        'Add volume to hips with embellishments',
        'Keep tops simple and supportive',
        'High-leg cuts make hips appear wider',
        'Balance your silhouette with bottom details'
      ]
    }
  },
  {
    id: 'rectangle',
    name: 'Rectangle',
    description: 'Straight silhouette with shoulders, waist, and hips in similar width',
    image: '/shape-rectangle.jpg',
    characteristics: [
      'Shoulders, waist, and hips similar width',
      'Minimal waist definition',
      'Athletic or straight build',
      'Often smaller bust'
    ],
    recommendations: {
      tops: [
        'Push-up or padded bikini tops',
        'Ruffled or embellished tops',
        'Bandeau styles',
        'Tops with bows or ties',
        'Bold prints and patterns'
      ],
      bottoms: [
        'Ruffled or skirted bottoms',
        'Side-tie bikini bottoms',
        'Brazilian cuts',
        'High-waisted with details',
        'Cheeky styles'
      ],
      onePieces: [
        'Belted swimsuits',
        'Criss-cross front designs',
        'Ruched sides',
        'Cut-out styles',
        'Push-up one-pieces'
      ],
      colors: [
        'Bright, bold colors',
        'Color blocking to create curves',
        'Light colors work well',
        'Mix and match brights'
      ],
      patterns: [
        'Large bold prints',
        'Horizontal stripes',
        'Floral patterns',
        'Tropical prints'
      ],
      avoid: [
        'Shapeless, loose styles',
        'All-black or very dark colors',
        'Minimal details',
        'Straight-cut one-pieces'
      ],
      tips: [
        'Create curves with ruffles and details',
        'Use color blocking to define waist',
        'Push-up tops add volume to bust',
        'Belts and ties create waist definition'
      ]
    }
  },
  {
    id: 'spoon',
    name: 'Spoon',
    description: 'Hips significantly wider than bust with a defined waist and shelf-like hips',
    image: '/shape-spoon.jpg',
    characteristics: [
      'Hips much wider than bust',
      'Defined waist',
      'Shelf-like hip appearance',
      'Slim upper body'
    ],
    recommendations: {
      tops: [
        'Patterned and ruffled tops',
        'Push-up styles for volume',
        'Off-shoulder designs',
        'Bandeau tops',
        'Bold colors and prints'
      ],
      bottoms: [
        'High-waisted bikini bottoms',
        'Dark, solid colors',
        'Ruched waistbands',
        'Avoid low-rise styles',
        'Fuller coverage'
      ],
      onePieces: [
        'Empire waist swimsuits',
        'Retro pin-up styles',
        'Ruching across waist',
        'Dark bottom with light top',
        'Tankinis with empire tops'
      ],
      colors: [
        'Light colors on top',
        'Dark colors on bottom',
        'Color blocking',
        'Avoid light colors on hips'
      ],
      patterns: [
        'Bold prints upstairs',
        'Solid dark downstairs',
        'Vertical details on bottom',
        'Diagonal patterns'
      ],
      avoid: [
        'Light colors on hips',
        'Horizontal stripes on bottom',
        'Low-rise bottoms',
        'Minimal coverage on hips'
      ],
      tips: [
        'High-waisted bottoms define your waist',
        'Draw attention upward with bold tops',
        'Empire waist styles are very flattering',
        'Ruching helps smooth and shape'
      ]
    }
  }
];

export const quizQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: 'How would you describe your shoulders?',
    options: [
      {
        id: 'narrow',
        text: 'Narrower than my hips',
        shapeScores: { pear: 3, spoon: 2, hourglass: 1 }
      },
      {
        id: 'balanced',
        text: 'Similar width to my hips',
        shapeScores: { hourglass: 3, rectangle: 2 }
      },
      {
        id: 'broad',
        text: 'Broader than my hips',
        shapeScores: { 'inverted-triangle': 3, rectangle: 1 }
      },
      {
        id: 'slim',
        text: 'Slim and rounded',
        shapeScores: { apple: 2, pear: 1, spoon: 1 }
      }
    ]
  },
  {
    id: 2,
    question: 'How would you describe your waist?',
    options: [
      {
        id: 'defined',
        text: 'Clearly defined and narrow',
        shapeScores: { hourglass: 3, pear: 2, spoon: 2 }
      },
      {
        id: 'slight',
        text: 'Slightly defined',
        shapeScores: { rectangle: 2, pear: 1, spoon: 1 }
      },
      {
        id: 'straight',
        text: 'Straight, minimal definition',
        shapeScores: { rectangle: 3, 'inverted-triangle': 2 }
      },
      {
        id: 'full',
        text: 'Fuller, rounder midsection',
        shapeScores: { apple: 3 }
      }
    ]
  },
  {
    id: 3,
    question: 'How would you describe your hips?',
    options: [
      {
        id: 'wide',
        text: 'Wide and curvy',
        shapeScores: { pear: 3, spoon: 3, hourglass: 1 }
      },
      {
        id: 'balanced-hips',
        text: 'Balanced with shoulders',
        shapeScores: { hourglass: 3, rectangle: 2 }
      },
      {
        id: 'narrow-hips',
        text: 'Narrow and slim',
        shapeScores: { 'inverted-triangle': 3, rectangle: 1 }
      },
      {
        id: 'shelf',
        text: 'Shelf-like, wider below waist',
        shapeScores: { spoon: 3, pear: 2 }
      }
    ]
  },
  {
    id: 4,
    question: 'How do your bust and hips compare?',
    options: [
      {
        id: 'bust-smaller',
        text: 'Bust is smaller than hips',
        shapeScores: { pear: 3, spoon: 3 }
      },
      {
        id: 'equal',
        text: 'Bust and hips are similar',
        shapeScores: { hourglass: 3, rectangle: 2 }
      },
      {
        id: 'bust-larger',
        text: 'Bust is larger than hips',
        shapeScores: { 'inverted-triangle': 3, apple: 1 }
      },
      {
        id: 'full-bust',
        text: 'Full bust with rounder tummy',
        shapeScores: { apple: 3 }
      }
    ]
  }
];

export const sizeGuides: SizeGuide[] = [
  {
    region: 'US',
    sizes: [
      { size: 'XS', bust: '32-33"', waist: '24-25"', hips: '34-35"' },
      { size: 'S', bust: '34-35"', waist: '26-27"', hips: '36-37"' },
      { size: 'M', bust: '36-37"', waist: '28-29"', hips: '38-39"' },
      { size: 'L', bust: '38-40"', waist: '30-32"', hips: '40-42"' },
      { size: 'XL', bust: '41-43"', waist: '33-35"', hips: '43-45"' },
      { size: 'XXL', bust: '44-46"', waist: '36-38"', hips: '46-48"' }
    ]
  },
  {
    region: 'UK',
    sizes: [
      { size: '8', bust: '32-33"', waist: '24-25"', hips: '34-35"' },
      { size: '10', bust: '34-35"', waist: '26-27"', hips: '36-37"' },
      { size: '12', bust: '36-37"', waist: '28-29"', hips: '38-39"' },
      { size: '14', bust: '38-40"', waist: '30-32"', hips: '40-42"' },
      { size: '16', bust: '41-43"', waist: '33-35"', hips: '43-45"' },
      { size: '18', bust: '44-46"', waist: '36-38"', hips: '46-48"' }
    ]
  },
  {
    region: 'EU',
    sizes: [
      { size: '34', bust: '82-84cm', waist: '61-63cm', hips: '86-89cm' },
      { size: '36', bust: '86-89cm', waist: '66-68cm', hips: '91-94cm' },
      { size: '38', bust: '91-94cm', waist: '71-73cm', hips: '97-99cm' },
      { size: '40', bust: '97-99cm', waist: '76-81cm', hips: '102-107cm' },
      { size: '42', bust: '102-107cm', waist: '84-89cm', hips: '109-114cm' },
      { size: '44', bust: '109-114cm', waist: '91-97cm', hips: '117-122cm' }
    ]
  }
];

export const confidenceTips: ConfidenceTip[] = [
  {
    id: '1',
    title: 'Embrace Your Unique Shape',
    description: 'Every body is beautiful. The key to confidence is finding styles that make YOU feel amazing, not trying to fit into someone else\'s idea of perfect.',
    icon: 'heart'
  },
  {
    id: '2',
    title: 'Colors That Make You Glow',
    description: 'Choose colors that complement your skin tone. Warm undertones shine in coral, peach, and gold, while cool undertones glow in blues, purples, and emerald.',
    icon: 'palette'
  },
  {
    id: '3',
    title: 'Confidence is Your Best Accessory',
    description: 'The most flattering thing you can wear is confidence. Stand tall, smile, and own your look. When you feel good, you look good!',
    icon: 'sparkles'
  },
  {
    id: '4',
    title: 'Finding the Right Support',
    description: 'Proper support makes all the difference. Look for underwire, adjustable straps, and quality fabrics that keep you comfortable all day.',
    icon: 'shield'
  },
  {
    id: '5',
    title: 'Mix and Match Freedom',
    description: 'Don\'t be afraid to mix tops and bottoms in different sizes, colors, or styles. Create a look that\'s uniquely yours!',
    icon: 'shuffle'
  },
  {
    id: '6',
    title: 'Quality Over Quantity',
    description: 'Invest in a few well-made pieces that fit perfectly rather than many ill-fitting options. Quality fabrics and construction last longer and feel better.',
    icon: 'gem'
  }
];

export const getBodyShapeById = (id: string): BodyShapeDetails | undefined => {
  return bodyShapes.find(shape => shape.id === id);
};

export const calculateBodyShape = (answers: Record<number, string>): { shape: BodyShapeDetails; confidence: number } => {
  const scores: Record<string, number> = {
    hourglass: 0,
    pear: 0,
    apple: 0,
    'inverted-triangle': 0,
    rectangle: 0,
    spoon: 0
  };

  // Calculate scores based on answers
  Object.entries(answers).forEach(([questionId, optionId]) => {
    const question = quizQuestions.find(q => q.id === parseInt(questionId));
    if (question) {
      const option = question.options.find(o => o.id === optionId);
      if (option) {
        Object.entries(option.shapeScores).forEach(([shape, score]) => {
          scores[shape] += score;
        });
      }
    }
  });

  // Find the shape with highest score
  let maxScore = 0;
  let winningShape = 'hourglass';
  
  Object.entries(scores).forEach(([shape, score]) => {
    if (score > maxScore) {
      maxScore = score;
      winningShape = shape;
    }
  });

  const shape = getBodyShapeById(winningShape);
  const totalPossible = 12; // 4 questions x max 3 points
  const confidence = Math.round((maxScore / totalPossible) * 100);

  return {
    shape: shape!,
    confidence
  };
};
