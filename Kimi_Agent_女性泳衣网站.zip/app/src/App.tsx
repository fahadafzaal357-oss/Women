import { useState, useEffect } from 'react';
import Navigation from '@/sections/Navigation';
import Hero from '@/sections/Hero';
import BodyShapeExplorer from '@/sections/BodyShapeExplorer';
import Quiz from '@/sections/Quiz';
import Recommendations from '@/sections/Recommendations';
import SizeGuide from '@/sections/SizeGuide';
import ConfidenceTips from '@/sections/ConfidenceTips';
import Footer from '@/sections/Footer';
import type { BodyShapeDetails } from '@/types';
import { Sparkles, RotateCcw } from 'lucide-react';

function App() {
  const [quizResult, setQuizResult] = useState<{ shape: BodyShapeDetails; confidence: number } | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);

  // Scroll to section handlers
  const scrollToQuiz = () => {
    document.getElementById('quiz')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToExplore = () => {
    document.getElementById('explore-shapes')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToRecommendations = () => {
    document.getElementById('recommendations')?.scrollIntoView({ behavior: 'smooth' });
  };

  // Handle quiz completion
  const handleQuizComplete = (result: { shape: BodyShapeDetails; confidence: number }) => {
    setQuizResult(result);
    setShowConfetti(true);
    
    // Scroll to recommendations after a short delay
    setTimeout(() => {
      scrollToRecommendations();
      setShowConfetti(false);
    }, 500);
  };

  // Handle shape selection from explorer
  const handleShapeSelect = (shape: BodyShapeDetails) => {
    setQuizResult({ shape, confidence: 85 });
    scrollToRecommendations();
  };

  // Handle retake quiz
  const handleRetakeQuiz = () => {
    setQuizResult(null);
    scrollToQuiz();
  };

  // Confetti effect
  useEffect(() => {
    if (!showConfetti) return;

    const createConfetti = () => {
      const colors = ['#FF6B7A', '#FFD4C7', '#8FB9A8', '#7EB5D6', '#E8D4A2'];
      const confettiCount = 50;
      
      for (let i = 0; i < confettiCount; i++) {
        const confetti = document.createElement('div');
        confetti.style.cssText = `
          position: fixed;
          width: ${Math.random() * 10 + 5}px;
          height: ${Math.random() * 10 + 5}px;
          background: ${colors[Math.floor(Math.random() * colors.length)]};
          left: ${Math.random() * 100}vw;
          top: -20px;
          border-radius: ${Math.random() > 0.5 ? '50%' : '0'};
          z-index: 9999;
          pointer-events: none;
          animation: confetti-fall ${Math.random() * 2 + 2}s linear forwards;
        `;
        document.body.appendChild(confetti);
        
        setTimeout(() => confetti.remove(), 4000);
      }
    };

    createConfetti();
  }, [showConfetti]);

  // Add confetti animation styles
  useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      @keyframes confetti-fall {
        0% {
          transform: translateY(0) rotate(0deg);
          opacity: 1;
        }
        100% {
          transform: translateY(100vh) rotate(720deg);
          opacity: 0;
        }
      }
      
      .animate-visible {
        opacity: 1 !important;
        transform: translateY(0) translateX(0) !important;
      }
    `;
    document.head.appendChild(style);
    
    return () => {
      document.head.removeChild(style);
    };
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      <main>
        {/* Hero Section */}
        <Hero 
          onStartQuiz={scrollToQuiz} 
          onExploreShapes={scrollToExplore} 
        />

        {/* Body Shape Explorer */}
        <BodyShapeExplorer onSelectShape={handleShapeSelect} />

        {/* Quiz Section */}
        <Quiz onComplete={handleQuizComplete} />

        {/* Recommendations Section - Only show if quiz is complete */}
        {quizResult && (
          <Recommendations
            shape={quizResult.shape}
            confidence={quizResult.confidence}
            onRetakeQuiz={handleRetakeQuiz}
          />
        )}

        {/* Size Guide */}
        <SizeGuide />

        {/* Confidence Tips */}
        <ConfidenceTips />
      </main>

      <Footer />

      {/* Floating action button for quick quiz access */}
      {!quizResult && (
        <button
          onClick={scrollToQuiz}
          className="fixed bottom-6 right-6 z-40 bg-[#FF6B7A] hover:bg-[#E85A6B] text-white px-5 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center gap-2 group"
        >
          <Sparkles className="w-5 h-5" />
          <span className="hidden sm:inline font-medium">Take Quiz</span>
        </button>
      )}

      {/* Back to quiz button when results are shown */}
      {quizResult && (
        <button
          onClick={handleRetakeQuiz}
          className="fixed bottom-6 right-6 z-40 bg-white hover:bg-[#FFF5F0] text-[#FF6B7A] px-5 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center gap-2 border border-[#FFE8E0] group"
        >
          <RotateCcw className="w-5 h-5" />
          <span className="hidden sm:inline font-medium">Retake Quiz</span>
        </button>
      )}
    </div>
  );
}

export default App;
