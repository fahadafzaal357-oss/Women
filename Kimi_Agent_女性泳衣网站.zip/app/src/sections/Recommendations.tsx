import { useEffect, useRef } from 'react';
import type { BodyShapeDetails } from '@/types';
import { 
  Sparkles, 
  Check, 
  X, 
  Heart, 
  Palette, 
  Shirt,
  Ruler,
  Lightbulb,
  ArrowRight
} from 'lucide-react';

interface RecommendationsProps {
  shape: BodyShapeDetails;
  confidence: number;
  onRetakeQuiz: () => void;
}

const Recommendations = ({ shape, confidence, onRetakeQuiz }: RecommendationsProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    const elements = sectionRef.current?.querySelectorAll('.animate-on-scroll');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="recommendations"
      className="section-padding bg-white relative"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Result header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 inline-flex items-center gap-2 px-4 py-2 bg-[#FF6B7A]/10 rounded-full text-[#FF6B7A] text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            Your Result
          </div>
          
          <h2 className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-100 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2D2D2D] mb-4">
            You Have a <span className="text-[#FF6B7A]">{shape.name}</span> Shape!
          </h2>
          
          <p className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-200 text-lg text-[#6B6B6B] mb-4">
            {shape.description}
          </p>
          
          <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-300 inline-flex items-center gap-2 px-4 py-2 bg-[#8FB9A8]/10 rounded-full text-[#8FB9A8] text-sm">
            <Check className="w-4 h-4" />
            {confidence}% confidence match
          </div>
        </div>

        {/* Characteristics */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-400 max-w-4xl mx-auto mb-12">
          <div className="bg-gradient-to-r from-[#FFF5F0] to-[#FFE8E0] rounded-2xl p-6 sm:p-8">
            <h3 className="font-display text-xl font-semibold text-[#2D2D2D] mb-4 flex items-center gap-2">
              <Heart className="w-5 h-5 text-[#FF6B7A]" />
              Your Shape Characteristics
            </h3>
            <div className="grid sm:grid-cols-2 gap-3">
              {shape.characteristics.map((char, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Check className="w-4 h-4 text-[#8FB9A8]" />
                  </div>
                  <span className="text-[#6B6B6B]">{char}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recommendations grid */}
        <div className="grid lg:grid-cols-2 gap-6 lg:gap-8 max-w-6xl mx-auto">
          {/* Tops */}
          <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-500 bg-white border border-[#FFE8E0] rounded-3xl p-6 sm:p-8 hover:shadow-coral transition-shadow">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 bg-[#FF6B7A]/10 rounded-xl flex items-center justify-center">
                <Shirt className="w-6 h-6 text-[#FF6B7A]" />
              </div>
              <h3 className="font-display text-xl font-semibold text-[#2D2D2D]">
                Best Bikini Tops
              </h3>
            </div>
            <ul className="space-y-3">
              {shape.recommendations.tops.map((top, i) => (
                <li key={i} className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#8FB9A8] mt-0.5 flex-shrink-0" />
                  <span className="text-[#6B6B6B]">{top}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Bottoms */}
          <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-600 bg-white border border-[#FFE8E0] rounded-3xl p-6 sm:p-8 hover:shadow-coral transition-shadow">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 bg-[#7EB5D6]/10 rounded-xl flex items-center justify-center">
                <Ruler className="w-6 h-6 text-[#7EB5D6]" />
              </div>
              <h3 className="font-display text-xl font-semibold text-[#2D2D2D]">
                Best Bikini Bottoms
              </h3>
            </div>
            <ul className="space-y-3">
              {shape.recommendations.bottoms.map((bottom, i) => (
                <li key={i} className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#8FB9A8] mt-0.5 flex-shrink-0" />
                  <span className="text-[#6B6B6B]">{bottom}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* One Pieces */}
          <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-700 bg-white border border-[#FFE8E0] rounded-3xl p-6 sm:p-8 hover:shadow-coral transition-shadow">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 bg-[#E8D4A2]/10 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-[#E8D4A2]" />
              </div>
              <h3 className="font-display text-xl font-semibold text-[#2D2D2D]">
                Flattering One-Pieces
              </h3>
            </div>
            <ul className="space-y-3">
              {shape.recommendations.onePieces.map((piece, i) => (
                <li key={i} className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#8FB9A8] mt-0.5 flex-shrink-0" />
                  <span className="text-[#6B6B6B]">{piece}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Colors & Patterns */}
          <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-800 bg-white border border-[#FFE8E0] rounded-3xl p-6 sm:p-8 hover:shadow-coral transition-shadow">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 bg-[#8FB9A8]/10 rounded-xl flex items-center justify-center">
                <Palette className="w-6 h-6 text-[#8FB9A8]" />
              </div>
              <h3 className="font-display text-xl font-semibold text-[#2D2D2D]">
                Colors & Patterns
              </h3>
            </div>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-[#2D2D2D] mb-2">Best Colors</h4>
                <div className="flex flex-wrap gap-2">
                  {shape.recommendations.colors.map((color, i) => (
                    <span
                      key={i}
                      className="px-3 py-1.5 bg-[#FFF5F0] rounded-full text-sm text-[#6B6B6B]"
                    >
                      {color}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-medium text-[#2D2D2D] mb-2">Best Patterns</h4>
                <div className="flex flex-wrap gap-2">
                  {shape.recommendations.patterns.map((pattern, i) => (
                    <span
                      key={i}
                      className="px-3 py-1.5 bg-[#FFE8E0] rounded-full text-sm text-[#6B6B6B]"
                    >
                      {pattern}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tips section */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-900 max-w-4xl mx-auto mt-12">
          <div className="bg-gradient-to-br from-[#2D2D2D] to-[#4A4A4A] rounded-3xl p-6 sm:p-8 text-white">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
                <Lightbulb className="w-6 h-6 text-[#FFD4C7]" />
              </div>
              <h3 className="font-display text-xl font-semibold">
                Pro Styling Tips
              </h3>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              {shape.recommendations.tips.map((tip, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#FF6B7A] flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold">{i + 1}</span>
                  </div>
                  <span className="text-white/90 text-sm">{tip}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* What to avoid */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-1000 max-w-4xl mx-auto mt-8">
          <div className="bg-[#FFF5F0] rounded-2xl p-6 sm:p-8 border border-[#FFE8E0]">
            <h3 className="font-display text-lg font-semibold text-[#2D2D2D] mb-4 flex items-center gap-2">
              <X className="w-5 h-5 text-[#E85A6B]" />
              Styles to Avoid
            </h3>
            <div className="flex flex-wrap gap-2">
              {shape.recommendations.avoid.map((item, i) => (
                <span
                  key={i}
                  className="px-3 py-1.5 bg-white rounded-full text-sm text-[#6B6B6B] border border-[#FFE8E0]"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-1100 text-center mt-12">
          <button
            onClick={onRetakeQuiz}
            className="inline-flex items-center gap-2 text-[#FF6B7A] font-semibold hover:underline"
          >
            <ArrowRight className="w-5 h-5" />
            Retake the Quiz
          </button>
        </div>
      </div>
    </section>
  );
};

export default Recommendations;
