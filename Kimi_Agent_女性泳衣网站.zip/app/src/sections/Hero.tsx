import { useEffect, useRef } from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';

interface HeroProps {
  onStartQuiz: () => void;
  onExploreShapes: () => void;
}

const Hero = ({ onStartQuiz, onExploreShapes }: HeroProps) => {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-visible');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = heroRef.current?.querySelectorAll('.animate-on-scroll');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={heroRef}
      className="relative min-h-screen flex items-center overflow-hidden bg-gradient-to-br from-[#FFFBF9] via-[#FFF5F0] to-[#FFE8E0]"
    >
      {/* Floating decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-64 h-64 bg-[#FF6B7A]/5 rounded-full blur-3xl floating-animation" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-[#FFD4C7]/20 rounded-full blur-3xl floating-animation" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-[#FF6B7A]/8 rounded-full blur-2xl floating-animation" style={{ animationDelay: '4s' }} />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 xl:px-12 py-20 lg:py-0">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left content */}
          <div className="order-2 lg:order-1 text-center lg:text-left">
            <div className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-700 ease-out">
              <span className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full text-[#FF6B7A] text-sm font-medium shadow-sm mb-6">
                <Sparkles className="w-4 h-4" />
                Find Your Perfect Fit
              </span>
            </div>

            <h1 className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-700 ease-out delay-100 font-display text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-[#2D2D2D] leading-tight mb-6">
              Discover the Bikini That{' '}
              <span className="text-[#FF6B7A]">Loves</span> Your Body
            </h1>

            <p className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-700 ease-out delay-200 text-lg sm:text-xl text-[#6B6B6B] mb-8 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              Take our quick quiz to find styles that flatter your unique shape and make you feel confident, comfortable, and absolutely radiant.
            </p>

            <div className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-700 ease-out delay-300 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button onClick={onStartQuiz} className="btn-primary inline-flex items-center justify-center gap-2 group">
                Start the Quiz
                <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
              </button>
              <button onClick={onExploreShapes} className="btn-secondary inline-flex items-center justify-center">
                Explore Body Shapes
              </button>
            </div>

            <div className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-700 ease-out delay-400 mt-10 flex items-center justify-center lg:justify-start gap-6 text-sm text-[#6B6B6B]">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-[#8FB9A8] rounded-full" />
                <span>6 Body Types</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-[#7EB5D6] rounded-full" />
                <span>Personalized Tips</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-[#E8D4A2] rounded-full" />
                <span>Size Guide</span>
              </div>
            </div>
          </div>

          {/* Right image */}
          <div className="order-1 lg:order-2 relative">
            <div className="animate-on-scroll opacity-0 translate-x-8 transition-all duration-700 ease-out delay-200 relative">
              {/* Decorative frame */}
              <div className="absolute -inset-4 bg-gradient-to-br from-[#FF6B7A]/20 to-[#FFD4C7]/30 rounded-[2rem] -z-10 transform rotate-3" />
              <div className="absolute -inset-4 bg-gradient-to-br from-[#FFD4C7]/30 to-[#FF6B7A]/20 rounded-[2rem] -z-20 transform -rotate-2" />
              
              {/* Main image */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl">
                <img
                  src="/hero-woman.jpg"
                  alt="Confident woman in coral bikini on beach"
                  className="w-full h-auto object-cover aspect-[3/4] lg:aspect-auto"
                />
                {/* Soft overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#FF6B7A]/10 to-transparent" />
              </div>

              {/* Floating badge */}
              <div className="absolute -bottom-4 -left-4 lg:-left-8 bg-white rounded-2xl shadow-xl p-4 animate-pulse-soft">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-[#FF6B7A]/10 rounded-full flex items-center justify-center">
                    <Sparkles className="w-6 h-6 text-[#FF6B7A]" />
                  </div>
                  <div>
                    <p className="font-semibold text-[#2D2D2D]">100%</p>
                    <p className="text-sm text-[#6B6B6B]">Confidence Boost</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
          <path
            d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z"
            fill="white"
          />
        </svg>
      </div>
    </section>
  );
};

export default Hero;
