import { useEffect, useRef, useState } from 'react';
import { sizeGuides } from '@/data/bodyShapes';
import { Ruler, Info, ChevronDown, ChevronUp } from 'lucide-react';

const SizeGuide = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [activeRegion, setActiveRegion] = useState('US');
  const [expandedSection, setExpandedSection] = useState<string | null>('bust');

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    const elements = sectionRef.current?.querySelectorAll('.animate-on-scroll');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const currentGuide = sizeGuides.find((g) => g.region === activeRegion);

  const measurementSteps = [
    {
      id: 'bust',
      title: 'How to Measure Your Bust',
      description: 'Measure around the fullest part of your bust, keeping the tape parallel to the floor. Don\'t pull too tight - you should be able to breathe comfortably.',
      tip: 'Wear a non-padded bra for the most accurate measurement.',
    },
    {
      id: 'waist',
      title: 'How to Measure Your Waist',
      description: 'Find the narrowest part of your torso, usually just above your belly button. Keep the tape snug but not tight, and don\'t suck in your stomach.',
      tip: 'Bend to one side - the natural crease is your waistline.',
    },
    {
      id: 'hips',
      title: 'How to Measure Your Hips',
      description: 'Measure around the fullest part of your hips and buttocks, keeping your feet together. The tape should be parallel to the floor.',
      tip: 'Stand in front of a mirror to ensure the tape is level.',
    },
  ];

  return (
    <section
      ref={sectionRef}
      id="size-guide"
      className="section-padding bg-gradient-to-br from-[#FFFBF9] via-[#FFF5F0] to-[#FFE8E0] relative"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 inline-block px-4 py-1.5 bg-white rounded-full text-[#FF6B7A] text-sm font-medium mb-4 shadow-sm">
            <Ruler className="w-4 h-4 inline mr-1" />
            Size Guide
          </span>
          <h2 className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-100 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2D2D2D] mb-4">
            Find Your Perfect Size
          </h2>
          <p className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-200 text-lg text-[#6B6B6B]">
            Use our size guide and measurement tips to ensure your bikini fits perfectly and feels amazing.
          </p>
        </div>

        {/* Measurement image */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-300 max-w-4xl mx-auto mb-12">
          <div className="relative rounded-3xl overflow-hidden shadow-xl">
            <img
              src="/measurement-guide.jpg"
              alt="Woman measuring her waist"
              className="w-full h-auto object-cover aspect-video"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#2D2D2D]/60 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6 text-white">
              <p className="text-lg font-medium">Accurate measurements are key to the perfect fit</p>
              <p className="text-white/80 text-sm">Follow our simple guide below</p>
            </div>
          </div>
        </div>

        {/* How to measure accordion */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-400 max-w-3xl mx-auto mb-12">
          <h3 className="font-display text-xl font-semibold text-[#2D2D2D] mb-4 flex items-center gap-2">
            <Info className="w-5 h-5 text-[#FF6B7A]" />
            How to Measure
          </h3>
          <div className="space-y-3">
            {measurementSteps.map((step) => (
              <div
                key={step.id}
                className="bg-white rounded-xl border border-[#FFE8E0] overflow-hidden"
              >
                <button
                  onClick={() => setExpandedSection(expandedSection === step.id ? null : step.id)}
                  className="w-full flex items-center justify-between p-4 text-left hover:bg-[#FFF5F0] transition-colors"
                >
                  <span className="font-medium text-[#2D2D2D]">{step.title}</span>
                  {expandedSection === step.id ? (
                    <ChevronUp className="w-5 h-5 text-[#6B6B6B]" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-[#6B6B6B]" />
                  )}
                </button>
                {expandedSection === step.id && (
                  <div className="px-4 pb-4">
                    <p className="text-[#6B6B6B] mb-3">{step.description}</p>
                    <div className="bg-[#8FB9A8]/10 rounded-lg p-3 flex items-start gap-2">
                      <Info className="w-4 h-4 text-[#8FB9A8] mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-[#6B6B6B]">{step.tip}</p>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Size chart */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-500 max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-coral overflow-hidden">
            {/* Region tabs */}
            <div className="flex border-b border-[#FFE8E0]">
              {sizeGuides.map((guide) => (
                <button
                  key={guide.region}
                  onClick={() => setActiveRegion(guide.region)}
                  className={`flex-1 py-4 px-6 font-medium text-sm transition-colors
                    ${
                      activeRegion === guide.region
                        ? 'text-[#FF6B7A] border-b-2 border-[#FF6B7A] bg-[#FFF5F0]'
                        : 'text-[#6B6B6B] hover:bg-[#FFF5F0]/50'
                    }`}
                >
                  {guide.region} Sizes
                </button>
              ))}
            </div>

            {/* Size table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-[#FFF5F0]">
                    <th className="px-6 py-4 text-left font-semibold text-[#2D2D2D]">Size</th>
                    <th className="px-6 py-4 text-left font-semibold text-[#2D2D2D]">Bust</th>
                    <th className="px-6 py-4 text-left font-semibold text-[#2D2D2D]">Waist</th>
                    <th className="px-6 py-4 text-left font-semibold text-[#2D2D2D]">Hips</th>
                  </tr>
                </thead>
                <tbody>
                  {currentGuide?.sizes.map((size, i) => (
                    <tr
                      key={size.size}
                      className={`border-b border-[#FFE8E0] last:border-b-0 hover:bg-[#FFF5F0]/50 transition-colors
                        ${i % 2 === 0 ? 'bg-white' : 'bg-[#FFFBF9]'}`}
                    >
                      <td className="px-6 py-4 font-medium text-[#FF6B7A]">{size.size}</td>
                      <td className="px-6 py-4 text-[#6B6B6B]">{size.bust}</td>
                      <td className="px-6 py-4 text-[#6B6B6B]">{size.waist}</td>
                      <td className="px-6 py-4 text-[#6B6B6B]">{size.hips}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Tips */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-600 max-w-3xl mx-auto mt-8">
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="bg-[#8FB9A8]/10 rounded-xl p-4">
              <h4 className="font-medium text-[#2D2D2D] mb-2 flex items-center gap-2">
                <Info className="w-4 h-4 text-[#8FB9A8]" />
                Between Sizes?
              </h4>
              <p className="text-sm text-[#6B6B6B]">
                If you&apos;re between sizes, we recommend sizing up for a more comfortable fit, especially for bikini bottoms.
              </p>
            </div>
            <div className="bg-[#7EB5D6]/10 rounded-xl p-4">
              <h4 className="font-medium text-[#2D2D2D] mb-2 flex items-center gap-2">
                <Info className="w-4 h-4 text-[#7EB5D6]" />
                Mix & Match
              </h4>
              <p className="text-sm text-[#6B6B6B]">
                Many women wear different sizes on top and bottom. Don&apos;t be afraid to mix sizes for the perfect fit!
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SizeGuide;
