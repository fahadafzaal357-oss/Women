import { useState, useEffect } from 'react';
import { Heart, Menu, X } from 'lucide-react';

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Explore Shapes', href: '#explore-shapes' },
    { label: 'Take Quiz', href: '#quiz' },
    { label: 'Size Guide', href: '#size-guide' },
    { label: 'Tips', href: '#confidence-tips' },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const element = document.querySelector(href);
    element?.scrollIntoView({ behavior: 'smooth' });
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300
          ${isScrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'}`}
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center gap-2"
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors
                ${isScrolled ? 'bg-[#FF6B7A]' : 'bg-white/20 backdrop-blur-sm'}`}>
                <Heart className="w-5 h-5 text-white" />
              </div>
              <span className={`font-display text-xl font-bold transition-colors
                ${isScrolled ? 'text-[#2D2D2D]' : 'text-[#2D2D2D]'}`}>
                BikiniFit
              </span>
            </a>

            {/* Desktop navigation */}
            <div className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => handleLinkClick(e, link.href)}
                  className={`text-sm font-medium transition-colors hover:text-[#FF6B7A]
                    ${isScrolled ? 'text-[#6B6B6B]' : 'text-[#6B6B6B]'}`}
                >
                  {link.label}
                </a>
              ))}
              <a
                href="#quiz"
                onClick={(e) => handleLinkClick(e, '#quiz')}
                className="bg-[#FF6B7A] hover:bg-[#E85A6B] text-white px-5 py-2.5 rounded-full text-sm font-medium transition-colors"
              >
                Start Quiz
              </a>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`md:hidden w-10 h-10 rounded-xl flex items-center justify-center transition-colors
                ${isScrolled ? 'bg-[#FFF5F0] text-[#2D2D2D]' : 'bg-white/20 backdrop-blur-sm text-[#2D2D2D]'}`}
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile menu */}
      <div
        className={`fixed inset-0 z-40 md:hidden transition-all duration-300
          ${isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'}`}
      >
        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)} />
        <div
          className={`absolute top-20 left-4 right-4 bg-white rounded-3xl shadow-xl p-6 transition-all duration-300
            ${isMobileMenuOpen ? 'translate-y-0 opacity-100' : '-translate-y-4 opacity-0'}`}
        >
          <div className="space-y-4">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                className="block py-3 px-4 text-[#2D2D2D] font-medium hover:bg-[#FFF5F0] rounded-xl transition-colors"
              >
                {link.label}
              </a>
            ))}
            <a
              href="#quiz"
              onClick={(e) => handleLinkClick(e, '#quiz')}
              className="block w-full text-center bg-[#FF6B7A] hover:bg-[#E85A6B] text-white py-3 px-4 rounded-xl font-medium transition-colors mt-4"
            >
              Start Quiz
            </a>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navigation;
