import { useEffect, useRef, useState } from 'react';
import { quizQuestions, calculateBodyShape } from '@/data/bodyShapes';
import type { BodyShapeDetails } from '@/types';
import { ChevronRight, ChevronLeft, Sparkles, RotateCcw, Check } from 'lucide-react';

interface QuizProps {
  onComplete: (result: { shape: BodyShapeDetails; confidence: number }) => void;
}

const Quiz = ({ onComplete }: QuizProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [isAnimating, setIsAnimating] = useState(false);
  const [direction, setDirection] = useState<'next' | 'prev'>('next');

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-visible');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = sectionRef.current?.querySelectorAll('.animate-on-scroll');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const handleAnswer = (optionId: string) => {
    setAnswers((prev) => ({ ...prev, [quizQuestions[currentQuestion].id]: optionId }));
  };

  const handleNext = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setDirection('next');
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentQuestion((prev) => prev + 1);
        setIsAnimating(false);
      }, 300);
    } else {
      // Quiz complete
      const result = calculateBodyShape(answers);
      onComplete(result);
    }
  };

  const handlePrev = () => {
    if (currentQuestion > 0) {
      setDirection('prev');
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentQuestion((prev) => prev - 1);
        setIsAnimating(false);
      }, 300);
    }
  };

  const handleRestart = () => {
    setAnswers({});
    setCurrentQuestion(0);
  };

  const currentQ = quizQuestions[currentQuestion];
  const progress = ((currentQuestion + 1) / quizQuestions.length) * 100;
  const hasAnswer = answers[currentQ.id];

  return (
    <section
      ref={sectionRef}
      id="quiz"
      className="section-padding bg-gradient-to-br from-[#FFFBF9] via-[#FFF5F0] to-[#FFE8E0] relative"
    >
      {/* Decorative elements */}
      <div className="absolute top-20 right-10 w-64 h-64 bg-[#FF6B7A]/5 rounded-full blur-3xl" />
      <div className="absolute bottom-20 left-10 w-48 h-48 bg-[#FFD4C7]/20 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 inline-block px-4 py-1.5 bg-white rounded-full text-[#FF6B7A] text-sm font-medium mb-4 shadow-sm">
            <Sparkles className="w-4 h-4 inline mr-1" />
            Body Shape Quiz
          </span>
          <h2 className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-100 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2D2D2D] mb-4">
            Let's Find Your Shape
          </h2>
          <p className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-200 text-lg text-[#6B6B6B]">
            Answer a few simple questions to discover your body shape and get personalized bikini recommendations.
          </p>
        </div>

        {/* Quiz card */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-300 max-w-3xl mx-auto">
          <div className="bg-white rounded-3xl shadow-coral-lg overflow-hidden">
            {/* Progress bar */}
            <div className="bg-[#FFF5F0] h-2">
              <div
                className="h-full bg-gradient-to-r from-[#FF6B7A] to-[#E85A6B] transition-all duration-500 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>

            {/* Question content */}
            <div className="p-6 sm:p-8 lg:p-10">
              {/* Question header */}
              <div className="flex items-center justify-between mb-6">
                <span className="text-sm text-[#6B6B6B]">
                  Question {currentQuestion + 1} of {quizQuestions.length}
                </span>
                <button
                  onClick={handleRestart}
                  className="text-sm text-[#FF6B7A] hover:underline flex items-center gap-1"
                >
                  <RotateCcw className="w-4 h-4" />
                  Restart
                </button>
              </div>

              {/* Question */}
              <div
                className={`transition-all duration-300 ${
                  isAnimating
                    ? direction === 'next'
                      ? 'opacity-0 -translate-x-8'
                      : 'opacity-0 translate-x-8'
                    : 'opacity-100 translate-x-0'
                }`}
              >
                <h3 className="font-display text-2xl sm:text-3xl font-semibold text-[#2D2D2D] mb-8">
                  {currentQ.question}
                </h3>

                {/* Options */}
                <div className="space-y-3">
                  {currentQ.options.map((option) => {
                    const isSelected = answers[currentQ.id] === option.id;
                    return (
                      <button
                        key={option.id}
                        onClick={() => handleAnswer(option.id)}
                        className={`w-full text-left p-4 sm:p-5 rounded-xl border-2 transition-all duration-200
                          ${
                            isSelected
                              ? 'border-[#FF6B7A] bg-[#FF6B7A]/5'
                              : 'border-[#FFE8E0] bg-white hover:border-[#FF6B7A]/30 hover:bg-[#FFF5F0]'
                          }`}
                      >
                        <div className="flex items-center gap-4">
                          <div
                            className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors
                              ${
                                isSelected
                                  ? 'border-[#FF6B7A] bg-[#FF6B7A]'
                                  : 'border-[#FFE8E0]'
                              }`}
                          >
                            {isSelected && <Check className="w-4 h-4 text-white" />}
                          </div>
                          <span
                            className={`text-base sm:text-lg ${
                              isSelected ? 'text-[#2D2D2D] font-medium' : 'text-[#6B6B6B]'
                            }`}
                          >
                            {option.text}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between mt-8 pt-6 border-t border-[#FFE8E0]">
                <button
                  onClick={handlePrev}
                  disabled={currentQuestion === 0}
                  className={`flex items-center gap-2 px-6 py-3 rounded-full font-medium transition-all
                    ${
                      currentQuestion === 0
                        ? 'text-[#A8A8A8] cursor-not-allowed'
                        : 'text-[#6B6B6B] hover:bg-[#FFF5F0]'
                    }`}
                >
                  <ChevronLeft className="w-5 h-5" />
                  Previous
                </button>

                <button
                  onClick={handleNext}
                  disabled={!hasAnswer}
                  className={`flex items-center gap-2 px-8 py-3 rounded-full font-medium transition-all
                    ${
                      hasAnswer
                        ? 'bg-[#FF6B7A] text-white hover:bg-[#E85A6B] hover:scale-[1.02]'
                        : 'bg-[#FFE8E0] text-[#A8A8A8] cursor-not-allowed'
                    }`}
                >
                  {currentQuestion === quizQuestions.length - 1 ? 'See Results' : 'Next'}
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Trust indicators */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-500 flex flex-wrap justify-center gap-6 mt-10 text-sm text-[#6B6B6B]">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-[#8FB9A8]/20 flex items-center justify-center">
              <Check className="w-3 h-3 text-[#8FB9A8]" />
            </div>
            <span>Takes 1 minute</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-[#7EB5D6]/20 flex items-center justify-center">
              <Check className="w-3 h-3 text-[#7EB5D6]" />
            </div>
            <span>Personalized results</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-[#E8D4A2]/20 flex items-center justify-center">
              <Check className="w-3 h-3 text-[#E8D4A2]" />
            </div>
            <span>Expert-backed tips</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Quiz;
