import { useEffect, useRef, useState } from 'react';
import { bodyShapes, getBodyShapeById } from '@/data/bodyShapes';
import type { BodyShapeDetails } from '@/types';
import { ChevronRight, X, Check, Sparkles } from 'lucide-react';

interface BodyShapeExplorerProps {
  onSelectShape: (shape: BodyShapeDetails) => void;
}

const BodyShapeExplorer = ({ onSelectShape }: BodyShapeExplorerProps) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [selectedShape, setSelectedShape] = useState<BodyShapeDetails | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    const elements = sectionRef.current?.querySelectorAll('.animate-on-scroll');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const handleShapeClick = (shapeId: string) => {
    const shape = getBodyShapeById(shapeId);
    if (shape) {
      setSelectedShape(shape);
    }
  };

  const closeModal = () => {
    setSelectedShape(null);
  };

  return (
    <section
      ref={sectionRef}
      id="explore-shapes"
      className="section-padding bg-white relative"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 inline-block px-4 py-1.5 bg-[#FF6B7A]/10 rounded-full text-[#FF6B7A] text-sm font-medium mb-4">
            Know Your Shape
          </span>
          <h2 className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-100 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2D2D2D] mb-4">
            Explore Your Body Shape
          </h2>
          <p className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-200 text-lg text-[#6B6B6B]">
            Every body is unique. Discover which shape resonates with you and learn the best styles to enhance your natural beauty.
          </p>
        </div>

        {/* Body shape cards grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {bodyShapes.map((shape, index) => (
            <div
              key={shape.id}
              className={`animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-${(index + 3) * 100}`}
            >
              <div
                onClick={() => handleShapeClick(shape.id)}
                className="group bg-white border border-[#FFE8E0] rounded-3xl p-6 lg:p-8 cursor-pointer
                           transition-all duration-300 ease-out
                           hover:border-[#FF6B7A]/30 hover:shadow-coral-lg hover:-translate-y-1"
              >
                {/* Image */}
                <div className="relative mb-6 aspect-square rounded-2xl overflow-hidden bg-gradient-to-br from-[#FFF5F0] to-[#FFE8E0]">
                  <img
                    src={shape.image}
                    alt={`${shape.name} body shape illustration`}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#FF6B7A]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>

                {/* Content */}
                <div className="text-center">
                  <h3 className="font-display text-xl lg:text-2xl font-semibold text-[#2D2D2D] mb-2 group-hover:text-[#FF6B7A] transition-colors">
                    {shape.name}
                  </h3>
                  <p className="text-[#6B6B6B] text-sm mb-4 line-clamp-2">
                    {shape.description}
                  </p>
                  <button className="inline-flex items-center gap-1 text-[#FF6B7A] font-medium text-sm group/btn">
                    Learn More
                    <ChevronRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-700 text-center mt-12">
          <p className="text-[#6B6B6B] mb-4">Not sure which shape you are?</p>
          <button
            onClick={() => document.getElementById('quiz')?.scrollIntoView({ behavior: 'smooth' })}
            className="inline-flex items-center gap-2 text-[#FF6B7A] font-semibold hover:underline"
          >
            <Sparkles className="w-5 h-5" />
            Take the Quiz to Find Out
          </button>
        </div>
      </div>

      {/* Modal for shape details */}
      {selectedShape && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-200">
            {/* Modal header */}
            <div className="sticky top-0 bg-white border-b border-[#FFE8E0] p-6 flex items-center justify-between">
              <h3 className="font-display text-2xl font-bold text-[#2D2D2D]">
                {selectedShape.name} Shape
              </h3>
              <button
                onClick={closeModal}
                className="w-10 h-10 rounded-full bg-[#FFF5F0] flex items-center justify-center text-[#6B6B6B] hover:bg-[#FFE8E0] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal content */}
            <div className="p-6">
              {/* Image and description */}
              <div className="flex flex-col md:flex-row gap-6 mb-8">
                <div className="w-full md:w-1/3 aspect-square rounded-2xl overflow-hidden bg-gradient-to-br from-[#FFF5F0] to-[#FFE8E0]">
                  <img
                    src={selectedShape.image}
                    alt={selectedShape.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <p className="text-[#6B6B6B] mb-4">{selectedShape.description}</p>
                  <h4 className="font-semibold text-[#2D2D2D] mb-2">Characteristics:</h4>
                  <ul className="space-y-1">
                    {selectedShape.characteristics.map((char, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-[#6B6B6B]">
                        <Check className="w-4 h-4 text-[#8FB9A8] mt-0.5 flex-shrink-0" />
                        {char}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Recommendations preview */}
              <div className="space-y-6">
                <div>
                  <h4 className="font-display text-lg font-semibold text-[#2D2D2D] mb-3 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-[#FF6B7A]" />
                    Best Bikini Tops
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedShape.recommendations.tops.slice(0, 4).map((top, i) => (
                      <span
                        key={i}
                        className="px-3 py-1.5 bg-[#FFF5F0] rounded-full text-sm text-[#2D2D2D]"
                      >
                        {top}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-display text-lg font-semibold text-[#2D2D2D] mb-3 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-[#FF6B7A]" />
                    Best Bikini Bottoms
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedShape.recommendations.bottoms.slice(0, 4).map((bottom, i) => (
                      <span
                        key={i}
                        className="px-3 py-1.5 bg-[#FFF5F0] rounded-full text-sm text-[#2D2D2D]"
                      >
                        {bottom}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-gradient-to-r from-[#FFF5F0] to-[#FFE8E0] rounded-2xl p-4">
                  <h4 className="font-semibold text-[#2D2D2D] mb-2">Pro Tip</h4>
                  <p className="text-sm text-[#6B6B6B]">{selectedShape.recommendations.tips[0]}</p>
                </div>
              </div>

              {/* CTA */}
              <div className="mt-8 pt-6 border-t border-[#FFE8E0]">
                <button
                  onClick={() => {
                    closeModal();
                    onSelectShape(selectedShape);
                  }}
                  className="w-full btn-primary"
                >
                  See Full Recommendations
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default BodyShapeExplorer;
