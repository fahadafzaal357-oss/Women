import { useEffect, useRef } from 'react';
import { confidenceTips } from '@/data/bodyShapes';
import { Heart, Palette, Sparkles, Shield, Shuffle, Gem, ArrowRight } from 'lucide-react';

const iconMap: Record<string, React.ElementType> = {
  heart: Heart,
  palette: Palette,
  sparkles: Sparkles,
  shield: Shield,
  shuffle: Shuffle,
  gem: Gem,
};

const ConfidenceTips = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    const elements = sectionRef.current?.querySelectorAll('.animate-on-scroll');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="confidence-tips"
      className="section-padding bg-white relative"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 inline-block px-4 py-1.5 bg-[#FF6B7A]/10 rounded-full text-[#FF6B7A] text-sm font-medium mb-4">
            <Sparkles className="w-4 h-4 inline mr-1" />
            Confidence Boosters
          </span>
          <h2 className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-100 font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2D2D2D] mb-4">
            Feel Amazing in Your Skin
          </h2>
          <p className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-200 text-lg text-[#6B6B6B]">
            Beyond finding the right bikini, here are some tips to help you feel confident, radiant, and absolutely beautiful.
          </p>
        </div>

        {/* Bikini collection image */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-300 max-w-5xl mx-auto mb-12">
          <div className="relative rounded-3xl overflow-hidden shadow-xl">
            <img
              src="/bikini-collection.jpg"
              alt="Beautiful collection of bikinis"
              className="w-full h-auto object-cover aspect-video"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#2D2D2D]/40 to-transparent" />
          </div>
        </div>

        {/* Tips grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {confidenceTips.map((tip, index) => {
            const Icon = iconMap[tip.icon] || Sparkles;
            return (
              <div
                key={tip.id}
                className={`animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-${(index + 4) * 100}`}
              >
                <div className="group bg-gradient-to-br from-[#FFFBF9] to-[#FFF5F0] rounded-3xl p-6 lg:p-8 h-full border border-[#FFE8E0] hover:border-[#FF6B7A]/30 hover:shadow-coral transition-all duration-300">
                  {/* Icon */}
                  <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300">
                    <Icon className="w-7 h-7 text-[#FF6B7A]" />
                  </div>

                  {/* Content */}
                  <h3 className="font-display text-xl font-semibold text-[#2D2D2D] mb-3">
                    {tip.title}
                  </h3>
                  <p className="text-[#6B6B6B] leading-relaxed">
                    {tip.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Quote section */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-1000 max-w-3xl mx-auto mt-16">
          <div className="relative text-center">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 text-8xl text-[#FF6B7A]/10 font-serif">
              &ldquo;
            </div>
            <blockquote className="relative z-10">
              <p className="font-display text-2xl sm:text-3xl text-[#2D2D2D] italic mb-4">
                The most beautiful thing you can wear is confidence.
              </p>
              <cite className="text-[#6B6B6B] not-italic">
                — Blake Lively
              </cite>
            </blockquote>
          </div>
        </div>

        {/* CTA */}
        <div className="animate-on-scroll opacity-0 translate-y-6 transition-all duration-600 delay-1100 text-center mt-12">
          <a
            href="#quiz"
            onClick={(e) => {
              e.preventDefault();
              document.getElementById('quiz')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="inline-flex items-center gap-2 btn-primary"
          >
            Find Your Perfect Bikini
            <ArrowRight className="w-5 h-5" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default ConfidenceTips;
